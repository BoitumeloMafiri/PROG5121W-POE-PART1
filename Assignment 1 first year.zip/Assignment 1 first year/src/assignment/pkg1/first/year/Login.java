/*
 * Login class - handles user registration and login
 * PROG5121 - Programming 1A
 */
package assignment.pkg1.first.year;

/**
 * This class validates usernames, passwords, and SA cell phone numbers.
 * It stores registered credentials and verifies login attempts.
 * 
 *
 * @author ST10106738
 */
public class Login {

    // User input fields
    private String username;
    private String password;
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;

    // Stored credentials after successful registration
    private String registeredUsername;
    private String registeredPassword;

    // Constructor
    public Login() {
        this.username = ""; // Stores the username entered during login
        this.password = ""; // Stores the password entered during login
        this.cellPhoneNumber = ""; // Stores the user's cell phone number
        this.firstName = ""; // Stores the user's first name
        this.lastName = ""; // Stores the user's last name
        this.registeredUsername = ""; // Holds the saved/registered username
        this.registeredPassword = ""; // Holds the saved/registered password
    }
    // Setter methods to update each field after object creation
    // --- Setters ---
    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setCellPhoneNumber(String cellPhoneNumber) {
        this.cellPhoneNumber = cellPhoneNumber;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    // --- Getters ---
    public String getUsername() {
        return username;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    /**
     * Checks if the username contains an underscore (_) and is no more than
     * 5 characters long.
     *
     * @return true if valid, false otherwise
     */
    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    /**
     * Checks password complexity:
     * - At least 8 characters
     * - Contains a capital letter
     * - Contains a number
     * - Contains a special character
     *
     * @return true if password meets all rules, false otherwise
     */
    public boolean checkPasswordComplexity() {
        if (password.length() < 8) {
            return false;
        }
        if (!password.matches(".*[A-Z].*")) {
            return false;
        }
        if (!password.matches(".*[0-9].*")) {
            return false;
        }
        // Special character = anything that is not a letter or digit
        return password.matches(".*[^a-zA-Z0-9].*");
    }

    /**
     * Checks if the cell phone number is a valid SA number.
     * Must start with +27 followed by 9 digits (e.g. +27838968976).
     * // SA cell numbers must start with the international dialling code +27
       // followed by 9 digits (e.g. +27838968976). I researched and tested
       // this regex pattern using the tool at https://regexr.com
       // Pattern used: ^\+27\d{9}$
     *
     * @return true if valid, false otherwise
     */
    public boolean checkCellPhoneNumber() {
        return cellPhoneNumber.matches("^\\+27\\d{9}$");
    }

    /**
     * Registers a new user after validating the provided username, password, and cell number.
     * Returns the first error found, or a success message if all pass.
     *
     * @return registration status message
     */
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, "
                    + "please ensure that your username contains an underscore "
                    + "and is no more than five characters in length.";
        }

        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted, "
                    + "please ensure that the password contains at least eight characters, "
                    + "a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber()) {
            return "Cell phone number is incorrectly formatted or does not contain "
                    + "an international code, please correct the number and try again.";
        }

        // All validations passed — store the credentials
        registeredUsername = username;
        registeredPassword = password;

        return "Username successfully captured.\n"
                + "Password successfully captured.\n"
                + "Cell phone number successfully added.\n"
                + firstName + " " + lastName + ", you have been registered successfully.";
    }

    /**
     * Checks if the entered username and password match the stored
     * registered credentials.
     *
     * @return true if login is successful, false otherwise
     */
    public boolean loginUser() {
        return username.equals(registeredUsername)
                && password.equals(registeredPassword);
    }

    /**
     * Returns a welcome message on successful login,
     * or an error message on failed login.
     *
     * @return login status message
     */
    public String returnLoginStatus() {
        if (loginUser()) {
            return "Welcome " + firstName + ", " + lastName
                    + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
