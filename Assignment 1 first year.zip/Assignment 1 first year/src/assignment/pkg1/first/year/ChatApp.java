/*
 * Main class - Registration and Login application
 * PROG5121 - Programming 1A
 * Boitumelo Mafiri - ST10106738
 */
package assignment.pkg1.first.year;

import java.util.Scanner;

/**
 * This is the main class that runs the Registration and Login menu.
 * Users can register an account and then log in.
 *
 * @author ST10106738
 */
public class ChatApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        while (true) {
            // Display the main menu
            System.out.println("\n===== Welcome to Our App! =====");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the leftover newline

            switch (choice) {
                case 1:
                    // --- Registration ---
                    System.out.print("Enter first name: ");
                    login.setFirstName(scanner.nextLine());

                    System.out.print("Enter last name: ");
                    login.setLastName(scanner.nextLine());

                    System.out.print("Enter username: ");
                    login.setUsername(scanner.nextLine());

                    System.out.print("Enter password: ");
                    login.setPassword(scanner.nextLine());

                    System.out.print("Enter SA cell phone number (e.g. +27838968976): ");
                    login.setCellPhoneNumber(scanner.nextLine());

                    // Validate and register
                    String result = login.registerUser();
                    System.out.println("\n" + result);
                    break;

                case 2:
                    // --- Login ---
                    System.out.print("Enter username: ");
                    login.setUsername(scanner.nextLine());

                    System.out.print("Enter password: ");
                    login.setPassword(scanner.nextLine());

                    // Check credentials and show status
                    String status = login.returnLoginStatus();
                    System.out.println("\n" + status);
                    break;

                case 3:
                    // --- Exit ---
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option, please try again.");
                    break;
            }
        }
    }
}
